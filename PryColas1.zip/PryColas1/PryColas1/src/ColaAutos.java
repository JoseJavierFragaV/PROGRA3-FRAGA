import java.util.LinkedList;
import java.util.Queue;

public class ColaAutos {
    private Queue<Auto> listaAutos;
    private Auto uDescolado;

    public ColaAutos() {
        listaAutos=new LinkedList<>();
        uDescolado =null;
    }

    public void encolar(Auto dato){
        listaAutos.add(dato);
    }

    public Auto desencolar()throws Exception{
        if(listaAutos.isEmpty())
            throw new Exception("Ya no existen autos encolados");
        uDescolado = listaAutos.poll();
        int anios = 2025 - uDescolado.getAnio();
        int pago = anios*50;
        System.out.println("Auto atendido"+uDescolado);
        System.out.println("El valor a pagar es: $"+pago);
        return uDescolado;
    }

    public Auto frente()throws Exception{
        if(listaAutos.isEmpty())
            throw new Exception("Ya no existen autos encolados");
        return listaAutos.peek();
    }

    public String listarTodos(){
        StringBuilder sb=new StringBuilder();
        for (Auto a1:listaAutos){
            sb.append(a1.toString());
        }
        return sb.toString();
    }

    public Auto getuDescolado(){
        return getuDescolado();
    }

   public int getPagouDescolado(){
        if(uDescolado == null) return 0;
        int anios = 2025 - uDescolado.getAnio();
        return anios*50;
   }
}
