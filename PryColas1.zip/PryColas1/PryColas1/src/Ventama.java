import  javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventama {
    private JPanel principal;
    private JComboBox cboMarca;
    private JTextField textAnio;
    private JButton btnEncolar;
    private JButton btnDesencolar;
    private JTextArea txtListado;
    private JLabel lblPago;
    private ColaAutos autos=new ColaAutos();

    public Ventama(){

        btnEncolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca=cboMarca.getSelectedItem().toString();
                int anio=Integer.parseInt(textAnio.getText());
                autos.encolar(new Auto(marca,anio));
                txtListado.setText(autos.listarTodos());
            }
        });
        btnDesencolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Auto atendido = autos.desencolar();
                    int pago = autos.getPagouDescolado();
                    txtListado.setText("Auto atendido:\n" + atendido.toString() +
                            "\nDebe pagar: $" + pago +
                            "\n\nAutos en cola:\n" + autos.listarTodos());
                    lblPago.setText("Pago: $" + pago);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                    txtListado.setText("");
                    lblPago.setText("Pago: $0");
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventama");
        frame.setContentPane(new Ventama().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 800);
        //frame.pack();
        frame.setVisible(true);
    }
}
