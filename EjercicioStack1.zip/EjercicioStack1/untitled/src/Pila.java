import javax.swing.*;
import java.util.Stack;
public class Pila {
   private Stack<String> coleccion;

   public Pila(){
       coleccion = new Stack<String>(); //Dentro del <> se puede deir que tipo de dato quiero
   }

   public void push(String dato){
       if (coleccion.size() >=10){
           JOptionPane.showMessageDialog(null, "Imposible ingresar 11 elementos");
       }
       coleccion.push(dato);

   }

   public String pop() throws Exception{

       if (coleccion.empty())
           throw new Exception("Imposible hacer esta accion");
       return coleccion.pop();
   }

   public String cima() throws Exception{
       return coleccion.peek();
   }

    @Override
    public String toString() {

       StringBuilder listado=new StringBuilder(); //clase que anexa toda dato y lo convierte en uno
       for(int i=coleccion.size()-1; i>=0; i-- ){
           listado.append(coleccion.get(i)+"\n"); //.append (agranda el string y anexa todos)
       }

       return listado.toString();

    }
}
