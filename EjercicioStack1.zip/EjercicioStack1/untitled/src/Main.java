import javax.swing.*;

public class Main {
    public static void main(String[] args) throws Exception {
        Pila data=new Pila();

        data.push("Elemento1");
        data.push("Elemento2");
        data.push("Elemento3");
        data.push("Elemento4");
        data.push("Elemento5");
        data.push("Elemento6");
        data.push("Elemento7");
        data.push("Elemento8");
        data.push("Elemento9");
        data.push("Elemento10");
        System.out.println("Pila");
        System.out.println(data.toString());
        String eliminado= null;
        try {
            eliminado = data.pop();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        JOptionPane.showMessageDialog(null, eliminado);
        System.out.println("Pila");
        System.out.println(data.toString());
        JOptionPane.showMessageDialog(null, "En la cima de la pila esta: "+data.cima());


    }
}
