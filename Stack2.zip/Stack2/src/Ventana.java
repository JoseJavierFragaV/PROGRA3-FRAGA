import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTextArea textArea1;
    private JButton btnComprobar;
    private JLabel txtCodigo;

    public Ventana() {
        btnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pila pilas=new Pila();
                String texto = txtCodigo.getText();

                for(int i=0; i<texto.length()-1;i++){
                    char letra=texto.charAt(i);
                    if(letra=='('|| letra =='('||letra=='('){
                        pilas.insertar(String.valueOf(letra));
                    }else{
                        if(letra==')'){
                            char salida=pilas.extraer().charAt(0);
                            if(salida!='('){
                                JOptionPane.showMessageDialog(null,"Codigo incorrecto");
                                return;
                            }
                        }else{
                            if(letra=='}'){
                                char salida=pilas.extraer().charAt(0);
                                if(salida!='{'){
                                    JOptionPane.showMessageDialog(null,"Codigo incorrecto");
                                    return;
                                }
                            }
                        }
                    }
                }
                if(pilas.esVacia()){
                    JOptionPane.showMessageDialog(null,"Correcto");
                }else{
                    JOptionPane.showMessageDialog(null,"Incorrecto");
                }

            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
