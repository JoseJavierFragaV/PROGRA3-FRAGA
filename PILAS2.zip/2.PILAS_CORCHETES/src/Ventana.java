import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTextField txtCodigo;
    private JTextArea textArea1;
    private JButton btnComprobar;

    public Ventana() {
        btnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pila pila = new Pila();
                String texto = txtCodigo.getText();
                textArea1.setText("");

                try {
                    for (int i = 0; i < texto.length(); i++) {
                        char letra = texto.charAt(i);

                        if (letra == '(' || letra == '{' || letra == '[') {
                            pila.insertar(String.valueOf(letra));
                            textArea1.append("Insertado: " + letra + "\n");
                        } else if (letra == ')' || letra == '}' || letra == ']') {
                            if (pila.esVacia()) {
                                textArea1.append("Error");
                                return;
                            }

                            String extraido = pila.extraer();
                            textArea1.append("Extraido: " + extraido + "\n");

                            if (!coincide(extraido.charAt(0), letra)) {
                                textArea1.append("Error: no coincide " + extraido + " con " + letra + "\n");
                                return;
                            }
                        }
                    }

                    if (pila.esVacia()) {
                        textArea1.append("Codigo correcto\n");
                    } else {
                        textArea1.append("Codigo incorrecto\n");
                    }

                } catch (Exception ex) {
                    textArea1.append("Error inesperado: " + ex.getMessage() + "\n");
                }
            }

            private boolean coincide(char apertura, char cierre) {
                return (apertura == '(' && cierre == ')') ||
                        (apertura == '{' && cierre == '}') ||
                        (apertura == '[' && cierre == ']');
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Verificador de Parentesis");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
